
/* eXist Native XML Database
 * Copyright (C) 2000-03,  Wolfgang M. Meier (wolfgang@exist-db.org)
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Library General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 * 
 * $Id: AbstractExpression.java,v 1.5 2004/10/20 16:54:17 wolfgang_m Exp $
 */

package org.exist.xquery;

import org.exist.dom.DocumentSet;
import org.exist.xquery.parser.XQueryAST;
import org.exist.xquery.value.Item;
import org.exist.xquery.value.Sequence;

public abstract class AbstractExpression implements Expression {

	protected XQueryContext context;

	protected XQueryAST astNode = null;
	
	protected DocumentSet contextDocSet = null;

	protected Expression parent = null;
	
	public AbstractExpression(XQueryContext context) {
		this.context = context;
	}

	public Sequence eval(Sequence contextSequence)
		throws XPathException {
		return eval(contextSequence, null);
	}

	public abstract Sequence eval(
		Sequence contextSequence,
		Item contextItem)
		throws XPathException;

	public abstract String pprint();

	public abstract int returnsType();

	public abstract void resetState();

	/**
	 * The default cardinality is {@link Cardinality#EXACTLY_ONE}.
	 */
	public int getCardinality() {
		return Cardinality.EXACTLY_ONE; // default cardinality
	}

	/**
	 * Ignored. Has no effect by default.
	 */
	public void setInPredicate(boolean inPredicate) {
	}

	/**
	 * Returns {@link Dependency#DEFAULT_DEPENDENCIES}.
	 * 
	 * @see org.exist.xquery.Expression#getDependencies()
	 */
	public int getDependencies() {
		return Dependency.DEFAULT_DEPENDENCIES;
	}

	public void setParent(Expression parent) {
		this.parent = parent;
	}
	
	public Expression getParent() {
		return parent;
	}
	
	public void setPrimaryAxis(int axis) {
	}
	
    /* (non-Javadoc)
     * @see org.exist.xquery.Expression#setContextDocSet(org.exist.dom.DocumentSet)
     */
    public void setContextDocSet(DocumentSet contextSet) {
        this.contextDocSet = contextSet;
    }
    
    public DocumentSet getContextDocSet() {
        return contextDocSet;
    }
    
	public void setASTNode(XQueryAST ast) {
		this.astNode = ast;
	}
	
	public XQueryAST getASTNode() {
		return astNode;
	}
}
