/*
 *  eXist Open Source Native XML Database
 *  Copyright (C) 2001-03 Wolfgang M. Meier
 *  wolfgang@exist-db.org
 *  http://exist.sourceforge.net
 *  
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  $Id: AbstractXMLDBTask.java,v 1.1 2003/11/17 09:27:31 wolfgang_m Exp $
 */
package org.exist.ant;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.Task;
import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Database;

/**
 * @author wolf
 */
public abstract class AbstractXMLDBTask extends Task {

	protected String driver = "org.exist.xmldb.DatabaseImpl";
	protected String user = "guest";
	protected String password = "guest";
	protected String uri = null;
	protected boolean createDatabase = false;

	/* (non-Javadoc)
	 * @see org.apache.tools.ant.Task#execute()
	 */
	public abstract void execute() throws BuildException;

	/**
		 * @param driver
		 */
	public void setDriver(String driver) {
		this.driver = driver;
	}

	/**
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @param user
	 */
	public void setUser(String user) {
		this.user = user;
	}

	/**
	* @param uri
	*/
	public void setUri(String uri) {
		this.uri = uri;
	}

	/**
	 * @param createDatabase
	 */
	public void setInitdb(boolean create) {
		this.createDatabase = create;
	}

	protected void registerDatabase() throws BuildException {
		try {
			Database dbs[] = DatabaseManager.getDatabases();
			for(int i = 0; i < dbs.length; i++) {
				if(dbs[i].acceptsURI(uri)) {
					log("Database driver already registered.");
					return;
				}
			}
			Class clazz = Class.forName(driver);
			Database database = (Database) clazz.newInstance();
			database.setProperty(
				"create-database",
				createDatabase ? "true" : "false");
			DatabaseManager.registerDatabase(database);
		} catch (Exception e) {
			throw new BuildException("failed to initialize XMLDB database driver");
		}
	}
}
