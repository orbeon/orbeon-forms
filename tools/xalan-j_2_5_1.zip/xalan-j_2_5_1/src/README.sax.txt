xml-commons/java/external/README.sax.txt $Id: README.sax.txt,v 1.1.1.1 2005/01/05 07:38:35 dsmall Exp $


HEAR YE, HEAR YE!


All of the .java software and associated documentation about 
SAX in this repository are distributed freely in the 
public domain.


LICENSE.sax.txt covers all software and documentation from the 
megginson.com including the following in the xml-commons project:

    xml-commons/java/external/src/org/xml/sax
      and all subdirectories
    xml-commons/java/external/xdocs/sax
      and all subdirectories


The actual SAX classes in xml-commons came from: 
    http://www.megginson.com/Software/index.html
	The original versions are tagged 'SAX-2_0-r2-prerelease'

