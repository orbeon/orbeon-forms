package com.thaiopensource.relaxng.impl;

public interface IdTypeMap {
  int getIdType(Name elementName, Name attributeName);
}
