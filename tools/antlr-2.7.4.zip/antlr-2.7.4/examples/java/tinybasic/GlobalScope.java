package tinybasic;

class GlobalScope extends Scope{
    public GlobalScope(Scope prev){
	super(prev);
    }
}
