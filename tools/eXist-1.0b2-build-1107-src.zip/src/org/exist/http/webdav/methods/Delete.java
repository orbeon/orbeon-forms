/*
 *  eXist Open Source Native XML Database
 *  Copyright (C) 2001-04 Wolfgang M. Meier
 *  wolfgang@exist-db.org
 *  http://exist-db.org
 *
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 * 
 *  $Id: Delete.java,v 1.6 2004/08/06 17:36:36 wolfgang_m Exp $
 */
package org.exist.http.webdav.methods;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.exist.EXistException;
import org.exist.collections.Collection;
import org.exist.collections.triggers.TriggerException;
import org.exist.dom.DocumentImpl;
import org.exist.security.Permission;
import org.exist.security.PermissionDeniedException;
import org.exist.security.User;
import org.exist.storage.BrokerPool;
import org.exist.storage.DBBroker;
import org.exist.util.Lock;
import org.exist.util.LockException;

/**
 * @author wolf
 */
public class Delete extends AbstractWebDAVMethod {
	
	public Delete(BrokerPool pool) {
		super(pool);
	}
	
	/* (non-Javadoc)
	 * @see org.exist.http.webdav.WebDAVMethod#process(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse, org.exist.collections.Collection, org.exist.dom.DocumentImpl)
	 */
	public void process(User user, HttpServletRequest request,
			HttpServletResponse response, String path) throws ServletException, IOException {
		DBBroker broker = null;
		Collection collection = null;
		DocumentImpl resource = null;
		try {
			broker = pool.get(user);
			collection = broker.openCollection(path, Lock.WRITE_LOCK);
			if(collection == null) {
				int pos = path.lastIndexOf('/');
				String collName = path.substring(0, pos);
				String docName = path.substring(pos + 1);
				LOG.debug("collection = " + collName + "; doc = " + docName);
				collection = broker.openCollection(collName, Lock.WRITE_LOCK);
				if(collection == null) {
					LOG.debug("No resource or collection found for path: " + path);
					response.sendError(HttpServletResponse.SC_NOT_FOUND, NOT_FOUND_ERR);
					return;
				}
				resource = collection.getDocument(broker, docName);
				if(resource == null) {
					LOG.debug("No resource found for path: " + path);
					response.sendError(HttpServletResponse.SC_NOT_FOUND, NOT_FOUND_ERR);
					return;
				}
			}
			if(!collection.getPermissions().validate(user, Permission.READ)) {
				LOG.debug("Permission denied to read collection");
				response.sendError(HttpServletResponse.SC_FORBIDDEN);
				return;
			}
			if(resource == null) {
				broker.removeCollection(collection);
			} else {
				if(resource.getResourceType() == DocumentImpl.BINARY_FILE)
					collection.removeBinaryResource(broker, resource.getFileName());
				else
					collection.removeDocument(broker, resource.getFileName());
			}
		} catch (EXistException e) {
			response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
		} catch (PermissionDeniedException e) {
			response.sendError(HttpServletResponse.SC_FORBIDDEN, e.getMessage());
		} catch (LockException e) {
			response.sendError(HttpServletResponse.SC_CONFLICT, e.getMessage());
		} catch (TriggerException e) {
			response.sendError(HttpServletResponse.SC_CONFLICT, e.getMessage());
		} finally {
			if(collection != null)
				collection.release();
			pool.release(broker);
		}
		response.setStatus(HttpServletResponse.SC_NO_CONTENT);
	}
}
