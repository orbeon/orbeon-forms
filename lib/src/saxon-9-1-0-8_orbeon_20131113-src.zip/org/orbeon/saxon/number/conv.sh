#!/bin/sh

 for file in *.java; do
     iconv -f ISO-8859-1 -t UTF8 $file > tmp.txt;
     mv tmp.txt $file
     echo $file
 done
