/*
 *  eXist Open Source Native XML Database
 *  Copyright (C) 2001-04 Wolfgang M. Meier
 *  wolfgang@exist-db.org
 *  http://exist.sourceforge.net
 *  
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  $Id: FunctionId.java,v 1.2 2004/10/08 14:01:15 wolfgang_m Exp $
 */
package org.exist.xquery;

import org.exist.dom.QName;

/**
 * @author wolf
 */
public class FunctionId implements Comparable {

	private QName qname;
	private int argCount;
	
	public FunctionId(QName qname, int arguments) {
		this.qname = qname;
		this.argCount = arguments;
	}
	 
	/* (non-Javadoc)
	 * @see java.lang.Comparable#compareTo(java.lang.Object)
	 */
	public int compareTo(Object o) {
		final FunctionId other = (FunctionId)o;
		final int cmp = qname.compareTo(other.qname);
		if(cmp == 0) {
			if(argCount == other.argCount || argCount == -1 || other.argCount == -1)
				return 0;
			else if(argCount > other.argCount)
				return 1;
			else
				return -1;
		} else
			return cmp;
	}
	
	public String toString() {
		return qname.toString() + '/' + argCount;
	}
}
