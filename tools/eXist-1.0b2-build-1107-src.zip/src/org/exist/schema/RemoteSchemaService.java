/*
 * Created on Apr 23, 2004
 *
 */
package org.exist.schema;

import org.exist.xmldb.RemoteCollection;

public class RemoteSchemaService extends GenericSchemaService {

	public RemoteSchemaService(RemoteCollection collection) {
		super(collection);
	}

}
