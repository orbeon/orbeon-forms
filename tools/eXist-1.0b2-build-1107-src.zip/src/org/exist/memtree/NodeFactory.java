/*
 * Created on Oct 20, 2003
 *
 * To change the template for this generated file go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
package org.exist.memtree;

/**
 * @author wolf
 *
 * To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Generation - Code and Comments
 */
public class NodeFactory {

	/**
	 * 
	 */
	public NodeFactory() {
		super();
		// TODO Auto-generated constructor stub
	}

}
