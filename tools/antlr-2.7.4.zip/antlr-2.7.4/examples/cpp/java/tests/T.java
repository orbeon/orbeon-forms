class T {
	static { int i; }

	public T() {
		this( (int) (r * 255), (int) (g * 255));
	}

	void foo() {
		final class U { int i; }
		Class c = int[].class;
		Class d = Object[].class;
		t.new T();
		((T)t).method();
		return "[i=" + (value) + "]";
		int q = (int)+3;
		int z = (int)4;
		int y = (z)+5;
		String s = (String) "ff";
		String t = (s)+"blort";
	}
}
