/*
*  eXist Open Source Native XML Database
*  Copyright (C) 2001-04 Wolfgang M. Meier (wolfgang@exist-db.org) 
*  and others (see http://exist-db.org)
*
*  This program is free software; you can redistribute it and/or
*  modify it under the terms of the GNU Lesser General Public License
*  as published by the Free Software Foundation; either version 2
*  of the License, or (at your option) any later version.
*
*  This program is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU Lesser General Public License for more details.
*
*  You should have received a copy of the GNU Lesser General Public License
*  along with this program; if not, write to the Free Software
*  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
* 
*  $Id: Receiver.java,v 1.1 2004/09/12 09:25:16 wolfgang_m Exp $
*/
package org.exist.util.serializer;

import org.exist.dom.QName;
import org.xml.sax.SAXException;

/**
 * A receiver is similar to the SAX content handler and lexical handler interfaces, but
 * uses some higher level types as arguments. For example, element names are internally
 * stored as QName objects, so startElement and endElement expect a QName. This way,
 * we avoid copying objects.
 * 
 * @author wolf
 */
public interface Receiver {
	
	public abstract void startDocument() throws SAXException;

	public abstract void endDocument() throws SAXException;

	public void startPrefixMapping(String prefix, String namespaceURI) throws SAXException;
	
	public void endPrefixMapping(String prefix) throws SAXException;
	
	public abstract void startElement(QName qname, AttrList attribs) throws SAXException;

	public abstract void endElement(QName qname) throws SAXException;

	public abstract void characters(CharSequence seq) throws SAXException;

	public abstract void attribute(QName qname, String value)
			throws SAXException;

	public abstract void comment(char[] ch, int start, int length)
			throws SAXException;
	
	public void processingInstruction(String target, String data) throws SAXException;
}