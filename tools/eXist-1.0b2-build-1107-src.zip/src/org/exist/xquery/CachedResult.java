/*
 *  eXist Open Source Native XML Database
 *  Copyright (C) 2001-04 Wolfgang M. Meier
 *  wolfgang@exist-db.org
 *  http://exist.sourceforge.net
 *  
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  $Id: CachedResult.java,v 1.1 2004/10/13 17:53:23 wolfgang_m Exp $
 */
package org.exist.xquery;

import org.exist.dom.NodeSet;
import org.exist.xquery.value.Sequence;
import org.exist.xquery.value.Type;

/**
 * This class is used to hold an intermediate result that can be cached.
 * Caching results is effective if a subexpression is executed more than once
 * and the current evaluation context doesn't change between invocations.
 * 
 * @author wolf
 */
public class CachedResult {

	protected Sequence cachedResult = null;
	protected Sequence cachedContext = null;
	protected int timestamp = 0;
	
	public CachedResult(NodeSet context, Sequence result) {
		this.cachedContext = context;
		this.cachedResult = result;
		this.timestamp = context.getState();
	}
	
	public Sequence getResult() {
		return cachedResult;
	}
	
	public boolean isValid(Sequence context) {
		if(Type.subTypeOf(context.getItemType(), Type.NODE) &&
			cachedContext == context) {
			if(((NodeSet)context).hasChanged(timestamp)) {
				return false;
			} else {
				cachedResult.setIsCached(true);
				return true;
			}
		}
		return false;
	}
}
