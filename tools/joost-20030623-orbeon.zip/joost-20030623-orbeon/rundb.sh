#!/bin/sh
jdb -classpath classes:lib/log4j.jar net.sf.joost.Main "$@"
