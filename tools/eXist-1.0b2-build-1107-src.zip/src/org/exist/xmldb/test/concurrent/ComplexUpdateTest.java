package org.exist.xmldb.test.concurrent;

import org.xmldb.api.modules.XMLResource;

/**
 * @author wolf
 */
public class ComplexUpdateTest extends ConcurrentTestBase {

	private final static String URI = "xmldb:exist:///db";
	
	private final static String XML =
		"<TEST><USER-SESSION-DATA version=\"0\"/></TEST>";
	
	public static void main(String[] args) {
		junit.textui.TestRunner.run(ComplexUpdateTest.class);
	}
	
	/**
	 * @param name
	 * @param uri
	 * @param testCollection
	 */
	public ComplexUpdateTest(String name) {
		super(name, URI, "complex");
	}
	
	/* (non-Javadoc)
	 * @see org.exist.xmldb.test.concurrent.ConcurrentTestBase#setUp()
	 */
	protected void setUp() throws Exception {
		super.setUp();
		
		XMLResource res = (XMLResource)getTestCollection().createResource("R01.xml", "XMLResource");
		res.setContent(XML);
		getTestCollection().storeResource(res);
		getTestCollection().close();
		
		addAction(new ComplexUpdateAction(URI + "/complex", "R01.xml", 200), 1, 0, 0);
	}
	
	/* (non-Javadoc)
	 * @see org.exist.xmldb.test.concurrent.ConcurrentTestBase#tearDown()
	 */
	protected void tearDown() throws Exception {
		DBUtils.shutdownDB(rootColURI);
	}

}
