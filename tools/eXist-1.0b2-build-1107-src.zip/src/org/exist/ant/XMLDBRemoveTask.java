/*
 *  eXist Open Source Native XML Database
 *  Copyright (C) 2001-03 Wolfgang M. Meier
 *  wolfgang@exist-db.org
 *  http://exist.sourceforge.net
 *  
 *  This program is free software; you can redistribute it and/or
 *  modify it under the terms of the GNU Lesser General Public License
 *  as published by the Free Software Foundation; either version 2
 *  of the License, or (at your option) any later version.
 *  
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Lesser General Public License for more details.
 *  
 *  You should have received a copy of the GNU Lesser General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *  
 *  $Id: XMLDBRemoveTask.java,v 1.1 2003/11/17 09:27:31 wolfgang_m Exp $
 */
package org.exist.ant;

import org.apache.tools.ant.BuildException;
import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.modules.CollectionManagementService;

/**
 * @author wolf
 */
public class XMLDBRemoveTask extends AbstractXMLDBTask {

	private String resource = null;
	private String collection = null;
	
	/* (non-Javadoc)
	 * @see org.apache.tools.ant.Task#execute()
	 */
	public void execute() throws BuildException {
		if (uri == null)
			throw new BuildException("You have to specify an XMLDB collection URI");
		if (resource == null && collection == null)
			throw new BuildException("Missing parameter: either resource or collection should " +				"be specified");
		try {
			Collection base = DatabaseManager.getCollection(uri, user, password);
			if(resource != null) {
				log("Removing resource: " + resource);
				Resource res = base.getResource(resource);
				if(res == null)
					throw new BuildException("Resource " + resource + " not found.");
				base.removeResource(res);
			} else {
				log("Removing collection: " + collection);
				CollectionManagementService service = (CollectionManagementService)
					base.getService("CollectionManagementService", "1.0");
				service.removeCollection(collection);
			}
		} catch(XMLDBException e) {
			throw new BuildException("XMLDB exception during remove: " + e.getMessage(), e);
		}
	}

	/**
	 * @param collection
	 */
	public void setCollection(String collection) {
		this.collection = collection;
	}

	/**
	 * @param resource
	 */
	public void setResource(String resource) {
		this.resource = resource;
	}

}
