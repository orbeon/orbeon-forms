/*****************************************************************************
 * Copyright (C) The Apache Software Foundation. All rights reserved.        *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the Apache Software License *
 * version 1.1, a copy of which has been included with this distribution in  *
 * the LICENSE file.                                                         *
 *****************************************************************************/

package org.apache.batik.bridge;

/**
 * This class is responsible for creating a GVT tree using an SVG DOM tree.
 *
 * @author <a href="mailto:tkormann@apache.org">Thierry Kormann</a>
 * @version $Id: DynamicGVTBuilder.java,v 1.2 2002/03/18 10:28:19 hillion Exp $
 */
public class DynamicGVTBuilder extends GVTBuilder {

    /**
     * Constructs a new builder.
     */
    public DynamicGVTBuilder() { }


}

