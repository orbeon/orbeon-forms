package org.exist.xmldb.test;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import junit.framework.TestCase;

import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;
import org.xmldb.api.DatabaseManager;
import org.xmldb.api.base.Collection;
import org.xmldb.api.base.Database;
import org.xmldb.api.base.Resource;
import org.xmldb.api.base.XMLDBException;
import org.xmldb.api.modules.XMLResource;

public class ResourceTest extends TestCase {

	private final static String URI = "xmldb:exist:///db";
	private final static String DRIVER = "org.exist.xmldb.DatabaseImpl";

	/**
	 * Constructor for XMLDBTest.
	 * @param arg0
	 */
	public ResourceTest(String arg0) {
		super(arg0);
	}
	
	public void testReadNonExistingResource() {
		try {
			Collection testCollection = DatabaseManager.getCollection(URI + "/test");
			assertNotNull(testCollection);
			Resource nonExistent = testCollection.getResource("12345.xml");
			assertNull(nonExistent);
		} catch(Exception e) {
			System.out.println("testReadNonExistingResource(): Exception: " + e);
			fail(e.getMessage());
		}
	}
	
	public void testReadResource() {
		try {
			Collection testCollection = DatabaseManager.getCollection(URI + "/test");
			assertNotNull(testCollection);
			String[] resources = testCollection.listResources();
			assertEquals(resources.length, testCollection.getResourceCount());

			System.out.println("reading " + resources[0]);
			XMLResource doc = (XMLResource) testCollection.getResource(resources[0]);
			assertNotNull(doc);

			System.out.println("testing XMLResource.getContentAsSAX()");
			StringWriter sout = new StringWriter();
			OutputFormat format = new OutputFormat("xml", "ISO-8859-1", true);
			format.setLineWidth(60);
			XMLSerializer xmlout = new XMLSerializer(sout, format);
			doc.getContentAsSAX(xmlout);
			System.out.println("----------------------------------------");
			System.out.println(sout.toString());
			System.out.println("----------------------------------------");
		} catch (Exception e) {
			System.out.println("testReadResource(): Exception: " + e);
			fail(e.getMessage());
		}
	}

	public void testReadDOM() {
		try {
			Collection testCollection = DatabaseManager.getCollection(URI + "/test");
			assertNotNull(testCollection);

			XMLResource doc = (XMLResource) testCollection.getResource("r_and_j.xml");
			assertNotNull(doc);
			Element elem = (Element) doc.getContentAsDOM();
			assertNotNull(elem);
			assertEquals(elem.getNodeName(), "PLAY");
			System.out.println("Root element: " + elem.getNodeName());
			NodeList children = elem.getChildNodes();
			Node node;
			for (int i = 0; i < children.getLength(); i++) {
				node = children.item(i);
				System.out.println("Child: " + node.getNodeName());
				assertNotNull(node);
				node = node.getFirstChild();
				while(node != null) {
					System.out.println("child: " + node.getNodeName());
					node = node.getNextSibling();
				}
			}
		} catch (XMLDBException e) {
			fail(e.getMessage());
		}
	}

	public void testSetContentAsSAX() {
		try {
			Collection testCollection = DatabaseManager.getCollection(URI + "/test");
			assertNotNull(testCollection);

			XMLResource doc =
				(XMLResource) testCollection.createResource("test.xml", "XMLResource");
			String xml =
				"<test><title>Title</title>"
					+ "<para>Paragraph1</para>"
					+ "<para>Paragraph2</para>"
					+ "</test>";
			ContentHandler handler = doc.setContentAsSAX();
			SAXParserFactory saxFactory = SAXParserFactory.newInstance();
			saxFactory.setNamespaceAware(true);
			saxFactory.setValidating(false);
			SAXParser sax = saxFactory.newSAXParser();
			XMLReader reader = sax.getXMLReader();
			reader.setContentHandler(handler);
			reader.parse(new InputSource(new StringReader(xml)));
			testCollection.storeResource(doc);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	public void testSetContentAsDOM() {
		try {
			Collection testCollection = DatabaseManager.getCollection(URI + "/test");
			assertNotNull(testCollection);

			XMLResource doc = (XMLResource) testCollection.createResource("dom.xml", "XMLResource");
			String xml =
				"<test><title>Title</title>"
					+ "<para>Paragraph1</para>"
					+ "<para>Paragraph2</para>"
					+ "</test>";
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = docFactory.newDocumentBuilder();
			Document dom = builder.parse(new InputSource(new StringReader(xml)));
			doc.setContentAsDOM(dom.getDocumentElement());
			testCollection.storeResource(doc);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	public void testAddRemove() {
		try {
			final String resourceID = "addremove.xml";

			XMLResource created = addResource(resourceID, xmlForTest());
			assertNotNull(created);
			// need to test documents xml structure			

			XMLResource located = resourceForId(resourceID);
			assertNotNull(located);
			//assertEquals((String) created.getContent(), (String) located.getContent());

			removeDocument(resourceID);
			XMLResource locatedAfterRemove = resourceForId(resourceID);
			assertNull(locatedAfterRemove);
		} catch (Exception e) {
			fail(e.getMessage());
		}
	}

	private void removeDocument(String id) throws XMLDBException {
		XMLResource resource = resourceForId(id);

		if (null != resource) {
			Collection collection = null;

			try {
				collection = DatabaseManager.getCollection(URI + "/test");
				collection.removeResource(resource);
			} finally {
				closeCollection(collection);
			}
		}
	}

	private XMLResource addResource(String id, String content) throws XMLDBException {
		Collection collection = null;
		XMLResource result = null;

		try {
			collection = DatabaseManager.getCollection(URI + "/test");
			result = (XMLResource) collection.createResource(id, XMLResource.RESOURCE_TYPE);
			result.setContent(content);
			collection.storeResource(result);
		} finally {
			closeCollection(collection);
		}

		return result;
	}

	private XMLResource resourceForId(String id) throws XMLDBException {
		Collection collection = null;
		XMLResource result = null;

		try {
			collection = DatabaseManager.getCollection(URI + "/test");
			result = (XMLResource) collection.getResource(id);
		} finally {
			closeCollection(collection);
		}

		return result;
	}

	private void closeCollection(Collection collection) throws XMLDBException {
		if (null != collection) {
			collection.close();
		}
	}

	private String xmlForTest() {
		return "<test><title>Title</title>"
			+ "<para>Paragraph1</para>"
			+ "<para>Paragraph2</para>"
			+ "</test>";
	}
	
	protected void setUp() {
		try {
			// initialize driver
			Class cl = Class.forName(DRIVER);
			Database database = (Database) cl.newInstance();
			database.setProperty("create-database", "true");
			DatabaseManager.registerDatabase(database);
		} catch (ClassNotFoundException e) {
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		} catch (XMLDBException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		junit.textui.TestRunner.run(ResourceTest.class);
		//junit.swingui.TestRunner.run(LexerTest.class);
	}
}