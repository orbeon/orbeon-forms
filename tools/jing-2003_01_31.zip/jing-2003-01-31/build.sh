#!/bin/sh

VERSION=1.3
JAVA_HOME="C:/Program Files/jdk1.4"
IDEA_HOME="C:/Program Files/idea-30"

# Compile
rm -r classes
rm jing-2003_01_31.jar
mkdir classes
"$JAVA_HOME/bin/javac" -classpath "xercesImpl.jar;ant.jar;iso-relax.jar" -g -d classes `find . -name *.java`
zip -9r jing-2003_01_31.jar META-INF `find . -name *.properties`
cd classes
zip -9r ../jing-2003_01_31.jar *

exit
"$JAVA_HOME/bin/jar" cf $JAR -C classes .
"$JAVA_HOME/bin/jar" uf $JAR META-INF

# Create source distrib
ARCHIVE=wrapper-src-$VERSION
rm -rf $ARCHIVE
mkdir $ARCHIVE
cp -r src META-INF README.txt LICENSE.txt build.sh $JAR $ARCHIVE
"$JAVA_HOME/bin/jar" cfM $ARCHIVE.zip $ARCHIVE
rm -rf $ARCHIVE
