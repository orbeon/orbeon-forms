#!/bin/sh
java -jar joost.jar "$@"
