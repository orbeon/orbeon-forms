/*****************************************************************************
 * Copyright (C) The Apache Software Foundation. All rights reserved.        *
 * ------------------------------------------------------------------------- *
 * This software is published under the terms of the Apache Software License *
 * version 1.1, a copy of which has been included with this distribution in  *
 * the LICENSE file.                                                         *
 *****************************************************************************/

package org.apache.batik.bridge;

/**
 * Defines a viewport.
 *
 * @author <a href="mailto:Thierry.Kormann@sophia.inria.fr">Thierry Kormann</a>
 * @version $Id: Viewport.java,v 1.1 2000/11/10 00:47:47 tkormann Exp $
 */
public interface Viewport {

    /**
     * Returns the width of this viewport.
     */
    public float getWidth();

    /**
     * Returns the height of this viewport.
     */
    public float getHeight();

}
